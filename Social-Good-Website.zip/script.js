var factList = [
  "In the US over 40 million Americans are uninsured or underinsured and another 58 million Americans are unable to access life saving drugs, resulting in the deaths of over 45,000 Americans annually",/*0*/
  "A 2018 study found that medical expenses pushed over 7 million people below the federal poverty line. Not only do people fall into poverty due to medical bills almost 530,000 people are forced to declare medical bankruptcy.",/*1*/
  "Over 121 low-income rural hospitals have shut down from 2010, leading US to only have a little over 6000 hospitals",/*2*/
  "Healthcare Costs Increased Twice as Fast as Worker Wages Over Last Decade"];/*3*/


var fact = document.getElementById("fact");
var myButton = document.getElementById("myButton");
var count = 0;

myButton.addEventListener("click", displayFact);

function displayFact(){
  fact.innerHTML = factList[count];
  count++;
  if (count == factList.length){
    count = 0;
  }
}